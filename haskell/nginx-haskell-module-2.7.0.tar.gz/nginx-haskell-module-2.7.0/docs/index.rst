Nginx Haskell module
====================

.. toctree::
   :maxdepth: 3

   yet-another-doc-with-examples/nginx-haskell-module-yadwe.rst
   haskell_modules_on_hackage.rst

